
import { GoogleGenAI, Type } from "@google/genai";
import { QuestionPaperContent } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // Initialize the client directly using the environment variable as per guidelines.
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async processImage(base64Image: string): Promise<QuestionPaperContent> {
    const prompt = `
      You are a specialized Sindhi Script Expert.
      Convert the image into a structured digital format. 

      SINDHI RECOGNITION RULES:
      1. Sindhi alphabet has 52 letters. Pay attention to dots:
         - 4 dots: ٿ, ڄ, ڃ, ڦ, ٽ
         - 3 dots: ث, چ, ش
         - 2 dots vertical: ٻ, پ, ڀ
         - Special: ڳ, ڱ, ڻ, ڊ, ڌ, ڍ
      2. If it is handwritten (like poetry), transcribe it line by line.
      3. If it is a printed paper (like "Aqsa Model High School"), preserve the header details exactly.

      SPECIFIC IMAGE GUIDANCE:
      - If you see "Aqsa Model High School Hala New", extract all header fields: Name, Class (II A), Subject (Sindhi), Date.
      - Transcribe questions such as "عورتون ڪھڙا ھٿ جا ھنر چاڻن ٿيون؟" and list items like "ڏنڊا، نروار، محت، قائداعظم".
      - If it is just poetry/text, put the entire text into the first section's title or questions.

      OUTPUT: Return ONLY a valid JSON object. Do not include markdown or text before/after.
    `;

    // Always follow the guideline for multimodal content structure: { parts: [...] }
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image.split(',')[1] || base64Image
            }
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingBudget: 16000 },
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            institutionName: { type: Type.STRING },
            examName: { type: Type.STRING },
            subject: { type: Type.STRING },
            classGrade: { type: Type.STRING },
            totalMarks: { type: Type.STRING },
            timeAllowed: { type: Type.STRING },
            sections: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  instructions: { type: Type.STRING },
                  questions: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        id: { type: Type.STRING },
                        text: { type: Type.STRING },
                        marks: { type: Type.STRING }
                      },
                      required: ["id", "text"]
                    }
                  }
                },
                required: ["title", "questions"]
              }
            }
          },
          required: ["institutionName", "examName", "subject", "sections"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("The AI returned an empty response.");

    try {
      const parsed = JSON.parse(text) as QuestionPaperContent;
      // Sanitize: ensure arrays exist
      if (!parsed.sections) parsed.sections = [];
      return parsed;
    } catch (error) {
      console.error("OCR Parse Failure:", text);
      throw new Error("Failed to process the text structure. Please ensure the photo is clear.");
    }
  }
}

export const geminiService = new GeminiService();
