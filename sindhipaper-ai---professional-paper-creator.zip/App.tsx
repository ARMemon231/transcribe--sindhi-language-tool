
import React, { useState } from 'react';
import { Download, FileText, RotateCcw, PenTool, Layout, CheckCircle, AlertCircle, Edit3, Save, Info } from 'lucide-react';
import { Uploader } from './components/Uploader';
import { PaperPreview } from './components/PaperPreview';
import { geminiService } from './services/geminiService';
import { QuestionPaperContent, ProcessingStatus, Section } from './types';

export default function App() {
  const [status, setStatus] = useState<ProcessingStatus>('idle');
  const [content, setContent] = useState<QuestionPaperContent | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const handleUpload = async (file: File) => {
    setStatus('processing');
    setError(null);
    
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        try {
          const result = await geminiService.processImage(base64);
          setContent(result);
          setStatus('success');
        } catch (err: any) {
          console.error(err);
          setError(err.message || 'Error occurred during Sindhi OCR. Handwriting might be too faint.');
          setStatus('error');
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError('Processing failed.');
      setStatus('error');
    }
  };

  const updateHeader = (field: keyof QuestionPaperContent, value: string) => {
    if (!content) return;
    setContent({ ...content, [field]: value });
  };

  const updateSection = (index: number, field: keyof Section, value: any) => {
    if (!content) return;
    const newSections = [...content.sections];
    newSections[index] = { ...newSections[index], [field]: value };
    setContent({ ...content, sections: newSections });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    setStatus('idle');
    setContent(null);
    setError(null);
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <header className="bg-white border-b sticky top-0 z-30 print:hidden shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg shadow-blue-100 shadow-lg">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-slate-900 leading-none">SindhiPaper AI</h1>
              <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-widest font-black">Teacher's Pro Tool</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {status === 'success' && content && (
              <>
                <button 
                  onClick={() => setIsEditing(!isEditing)}
                  className={`flex items-center gap-2 px-4 py-2 text-sm font-bold rounded-xl transition-all ${isEditing ? 'bg-green-600 text-white shadow-lg' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                >
                  {isEditing ? <><Save className="w-4 h-4" /> Finish Editing</> : <><Edit3 className="w-4 h-4" /> Edit Text</>}
                </button>
                <div className="h-6 w-px bg-slate-200"></div>
                <button 
                  onClick={handlePrint}
                  className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white font-black rounded-xl hover:bg-blue-700 shadow-xl shadow-blue-200 transition-all active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  Save as PDF
                </button>
                <button onClick={handleReset} className="p-2 text-slate-400 hover:text-red-500 transition-colors">
                  <RotateCcw className="w-5 h-5" />
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-8">
        {!content && (status === 'idle' || status === 'error') && (
          <div className="max-w-3xl mx-auto mt-8 space-y-10">
            <div className="text-center space-y-4">
              <h2 className="text-5xl font-black text-slate-900 tracking-tight leading-tight">
                Digitize <span className="text-blue-600">Sindhi Scripts</span> with AI
              </h2>
              <p className="text-xl text-slate-600 max-w-2xl mx-auto">
                Upload images of handwritten notes or printed exams. Our AI specializes in high-accuracy Sindhi character recognition.
              </p>
            </div>

            {error && (
              <div className="bg-red-50 border-2 border-red-200 rounded-3xl p-6 flex gap-4 animate-in fade-in zoom-in duration-300 shadow-sm">
                <AlertCircle className="w-6 h-6 text-red-600 shrink-0 mt-1" />
                <div className="space-y-3">
                  <h4 className="font-bold text-red-900">Script Detection Issue</h4>
                  <p className="text-red-700 text-sm leading-relaxed">{error}</p>
                  <button onClick={handleReset} className="text-sm font-black text-red-900 hover:underline">RETRY SCAN</button>
                </div>
              </div>
            )}
            
            <Uploader onUpload={handleUpload} isLoading={false} />
            
            <div className="bg-blue-900 p-8 rounded-[2.5rem] text-white flex flex-col md:flex-row gap-8 items-center">
              <div className="space-y-4 flex-1">
                <h3 className="text-2xl font-bold">How it works</h3>
                <ul className="space-y-3 text-blue-200 text-sm">
                  <li className="flex gap-2"><span>1.</span> Upload photo of handwritten or printed Sindhi text.</li>
                  <li className="flex gap-2"><span>2.</span> AI identifies complex characters like ڳ, ڄ, and ڦ.</li>
                  <li className="flex gap-2"><span>3.</span> Review the text, edit mistakes, and save as A4 PDF.</li>
                </ul>
              </div>
              <div className="w-full md:w-48 h-48 bg-white/10 rounded-3xl flex items-center justify-center border border-white/20">
                <PenTool className="w-16 h-16 text-blue-400" />
              </div>
            </div>
          </div>
        )}

        {status === 'processing' && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-8 animate-in fade-in">
            <div className="relative">
              <div className="w-32 h-32 border-8 border-blue-100 rounded-full"></div>
              <div className="absolute inset-0 w-32 h-32 border-8 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <FileText className="w-10 h-10 text-blue-600 animate-pulse" />
              </div>
            </div>
            <div className="space-y-3">
              <h3 className="text-3xl font-black text-slate-800">Transcribing Sindhi Script...</h3>
              <p className="text-slate-500 max-w-md mx-auto italic font-medium">
                Our advanced AI is mapping 52 unique Sindhi characters. Please wait...
              </p>
            </div>
          </div>
        )}

        {content && status === 'success' && (
          <div className={`grid lg:grid-cols-[1fr_${isEditing ? '450px' : '360px'}] gap-8 mt-4 animate-in fade-in slide-in-from-bottom-8 duration-700`}>
            {/* Paper Preview */}
            <div className="bg-slate-200/50 p-4 md:p-12 rounded-[2.5rem] border border-slate-300 shadow-inner overflow-auto flex justify-center">
              <PaperPreview content={content} />
            </div>

            {/* Sidebar Control Panel */}
            <div className="space-y-6 print:hidden">
              {isEditing ? (
                <div className="bg-white p-6 rounded-3xl border-2 border-slate-300 shadow-2xl space-y-6 max-h-[80vh] overflow-y-auto">
                  <h3 className="text-xl font-bold text-slate-900 border-b pb-4 flex items-center gap-2">
                    <Edit3 className="w-5 h-5 text-blue-600" /> Manual Edit Mode
                  </h3>
                  
                  <div className="space-y-4" dir="rtl">
                    <div className="space-y-1">
                      <label className="text-xs uppercase font-bold text-slate-700 block pr-1 mb-1">Institution Name</label>
                      <input 
                        className="w-full p-3 bg-white border-2 border-slate-300 rounded-xl sindhi-text text-xl text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm"
                        value={content.institutionName} 
                        onChange={(e) => updateHeader('institutionName', e.target.value)}
                        placeholder="اسڪول جو نالو"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs uppercase font-bold text-slate-700 block pr-1 mb-1">Subject</label>
                      <input 
                        className="w-full p-3 bg-white border-2 border-slate-300 rounded-xl sindhi-text text-xl text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm"
                        value={content.subject} 
                        onChange={(e) => updateHeader('subject', e.target.value)}
                        placeholder="مضمون"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs uppercase font-bold text-slate-700 block pr-1 mb-1">Total Marks</label>
                        <input 
                          className="w-full p-3 bg-white border-2 border-slate-300 rounded-xl sindhi-text text-xl text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm"
                          value={content.totalMarks} 
                          onChange={(e) => updateHeader('totalMarks', e.target.value)}
                          placeholder="ڪل مارڪون"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs uppercase font-bold text-slate-700 block pr-1 mb-1">Time Allowed</label>
                        <input 
                          className="w-full p-3 bg-white border-2 border-slate-300 rounded-xl sindhi-text text-xl text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm"
                          value={content.timeAllowed} 
                          onChange={(e) => updateHeader('timeAllowed', e.target.value)}
                          placeholder="وقت"
                        />
                      </div>
                    </div>
                    
                    {content.sections.map((sec, sIdx) => (
                      <div key={sIdx} className="pt-4 border-t-2 border-slate-100 space-y-4">
                        <label className="text-xs uppercase font-bold text-slate-700 block pr-1 mb-1">Section {sIdx + 1} Title</label>
                        <input 
                          className="w-full p-3 bg-white border-2 border-blue-200 rounded-xl sindhi-text font-bold text-xl text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all shadow-sm"
                          value={sec.title} 
                          onChange={(e) => updateSection(sIdx, 'title', e.target.value)}
                          placeholder="حصي جو عنوان"
                        />
                        {sec.questions.map((q, qIdx) => (
                          <div key={q.id} className="space-y-1 pl-4 border-r-4 border-slate-200 bg-slate-50/50 p-2 rounded-lg">
                             <label className="text-xs font-bold text-slate-600">Question {qIdx + 1}</label>
                             <textarea 
                              className="w-full p-3 bg-white border-2 border-slate-300 rounded-xl sindhi-text text-xl text-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none min-h-[100px] transition-all shadow-sm"
                              value={q.text} 
                              onChange={(e) => {
                                const newQs = [...sec.questions];
                                newQs[qIdx] = { ...newQs[qIdx], text: e.target.value };
                                updateSection(sIdx, 'questions', newQs);
                              }}
                              placeholder="سوال لکو"
                             />
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={() => setIsEditing(false)}
                    className="w-full py-4 bg-green-600 text-white font-black rounded-2xl shadow-xl hover:bg-green-700 transition-all flex items-center justify-center gap-2"
                  >
                    <CheckCircle className="w-5 h-5" />
                    APPLY CHANGES
                  </button>
                </div>
              ) : (
                <div className="bg-white p-6 rounded-3xl border-2 border-slate-200 shadow-xl space-y-6">
                  <div className="bg-green-50 p-4 rounded-2xl flex items-center gap-3 text-green-700">
                    <CheckCircle className="w-6 h-6 shrink-0" />
                    <span className="font-black text-lg">OCR Success</span>
                  </div>
                  
                  <div className="space-y-4">
                    <p className="text-sm text-slate-600 leading-relaxed font-medium">
                      Sindhi script detection complete. Review the digital layout on the left and save as PDF for printing.
                    </p>
                    
                    <button 
                      onClick={handlePrint}
                      className="w-full py-4 bg-blue-600 text-white rounded-[1.25rem] font-black text-xl flex items-center justify-center gap-3 hover:bg-blue-700 shadow-2xl shadow-blue-300 transition-all hover:-translate-y-1 active:scale-95"
                    >
                      <Download className="w-6 h-6" />
                      DOWNLOAD PDF
                    </button>

                    <div className="p-4 bg-blue-50 rounded-2xl border-2 border-blue-100 flex gap-3">
                       <Info className="w-5 h-5 text-blue-600 shrink-0" />
                       <div className="space-y-1">
                          <h5 className="font-bold text-blue-900 text-xs uppercase">Saving Instructions</h5>
                          <p className="text-[11px] text-blue-700 leading-relaxed font-medium">
                            The button above opens the browser's <strong>Print Menu</strong>. In the 'Destination' list, simply choose <strong>"Save as PDF"</strong> to download your Sindhi paper.
                          </p>
                       </div>
                    </div>

                    <button 
                      onClick={() => setIsEditing(true)}
                      className="w-full py-3 bg-white text-slate-700 border-2 border-slate-200 rounded-xl font-bold text-sm hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
                    >
                      <Edit3 className="w-4 h-4 text-blue-500" />
                      Correct Mistakes
                    </button>
                  </div>
                </div>
              )}

              <div className="bg-slate-900 p-6 rounded-[2rem] text-white shadow-2xl space-y-4">
                <h4 className="font-bold flex items-center gap-2 text-blue-400">
                  <Layout className="w-4 h-4" />
                  Format Specifications
                </h4>
                <div className="space-y-2">
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    <strong>Font:</strong> Lateef Pro (Optimized for Sindhi Dots)
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    <strong>Layout:</strong> International A4 Standard
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    <strong>Reading:</strong> Right-to-Left (RTL) Enabled
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
